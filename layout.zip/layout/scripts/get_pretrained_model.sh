#! /bin/bash
mkdir ../bin
wget http://sketch-code.s3.amazonaws.com/model_json_weights/model_json.json -O ../bin/model_json.json
wget http://sketch-code.s3.amazonaws.com/model_json_weights/weights.h5 -O ../bin/weights.h5


